namespace AppleAuth.Api.Dtos
{
    public class CreateOrderRequest
    {
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string? CouponCode { get; set; }
        public List<OrderItemDto> Items { get; set; } = new();
    }

    public class OrderItemDto
    {
        public string Name { get; set; } = string.Empty;
        public int Price { get; set; }
        public int Qty { get; set; }
    }
}