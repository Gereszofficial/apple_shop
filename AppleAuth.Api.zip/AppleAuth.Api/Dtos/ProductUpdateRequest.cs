namespace AppleAuth.Api.Dtos
{
    public class ProductUpdateRequest : ProductCreateRequest {}
}