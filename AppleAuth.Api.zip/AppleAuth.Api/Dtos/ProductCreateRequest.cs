namespace AppleAuth.Api.Dtos
{
    public class ProductCreateRequest
    {
        public string Name { get; set; } = string.Empty;
        public string? Slug { get; set; }
        public string? Description { get; set; }
        public string? Category { get; set; }
        public string? Images { get; set; }
        public string? Colors { get; set; }
        public string? SpecsJson { get; set; }
        public int Price { get; set; }
        public int Stock { get; set; }
    }
}