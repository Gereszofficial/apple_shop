using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AppleAuth.Api.Models
{
    public class Order
    {
        public int Id { get; set; }
        [Required] public int UserId { get; set; }
        [Required, MaxLength(160)] public string FullName { get; set; } = string.Empty;
        [Required, MaxLength(160)] public string Email { get; set; } = string.Empty;
        [MaxLength(280)] public string Address { get; set; } = string.Empty;
        public int Subtotal { get; set; }
        public int Discount { get; set; }
        public int Total { get; set; }
        public string? CouponCode { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public List<OrderItem> Items { get; set; } = new();
    }

    public class OrderItem
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public int ProductPrice { get; set; }
        public int Qty { get; set; }
    }
}