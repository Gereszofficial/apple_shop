using System.ComponentModel.DataAnnotations;

namespace AppleAuth.Api.Models
{
    public class UserProfile
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        [MaxLength(160)] public string FullName { get; set; } = string.Empty;
        [MaxLength(40)] public string Phone { get; set; } = string.Empty;
        [MaxLength(280)] public string Address { get; set; } = string.Empty;
        [MaxLength(500)] public string AvatarUrl { get; set; } = string.Empty;
    }
}