using System.ComponentModel.DataAnnotations;

namespace AppleAuth.Api.Models
{
    public class Product
    {
        public int Id { get; set; }
        [Required, MaxLength(160)]
        public string Name { get; set; } = string.Empty;
        [MaxLength(160)]
        public string Slug { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Images { get; set; } = "[]"; // JSON array
        public string Colors { get; set; } = "[]"; // JSON array
        public string SpecsJson { get; set; } = "{}"; // JSON map
        public int Price { get; set; } // HUF
        public int Stock { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}