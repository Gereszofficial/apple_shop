using System.ComponentModel.DataAnnotations;

namespace AppleAuth.Api.Models
{
    public class Coupon
    {
        public int Id { get; set; }
        [Required, MaxLength(40)] public string Code { get; set; } = string.Empty;
        public int PercentOff { get; set; } // 0..100
        public int AmountOff { get; set; } // HUF
        public bool IsActive { get; set; } = true;
        public DateTime? ExpiresAt { get; set; }
    }
}