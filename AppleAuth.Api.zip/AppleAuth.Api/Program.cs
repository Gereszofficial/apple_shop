using AppleAuth.Api.Data;
using AppleAuth.Api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// === Services ===

// EF Core (SQLite)
builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// JWT Auth
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]!))
        };
    });

builder.Services.AddAuthorization();

builder.Services.AddScoped<TokenService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "AppleAuth.Api", Version = "v1" });

    // JWT in Swagger
    var jwtScheme = new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Add meg az 'Bearer {token}' értéket."
    };
    c.AddSecurityDefinition("Bearer", jwtScheme);
    c.AddSecurityRequirement(new OpenApiSecurityRequirement { { jwtScheme, Array.Empty<string>() } });
});

// CORS for Vite dev server
builder.Services.AddCors(o =>
{
    o.AddPolicy("web", p =>
        p.WithOrigins("http://localhost:5173").AllowAnyHeader().AllowAnyMethod());
});

var app = builder.Build();

// === Pipeline ===
app.UseCors("web");

app.UseSwagger();
app.UseSwaggerUI();

app.UseStaticFiles();

app.UseAuthentication();
app.UseAuthorization();

// === DB ensure + seed (products, coupons, admin) ===
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();

    if (!db.Products.Any())
    {
        db.Products.AddRange(new[] {
            new AppleAuth.Api.Models.Product { Name="iPhone 15 Pro", Slug="iphone-15-pro", Description="Titan erő. Pro teljesítmény.", Category="iPhone", Price=499990, Stock=15, Images="[\"/img/iphone15pro.png\"]", SpecsJson="{\"chip\":\"A17 Pro\"}" },
            new AppleAuth.Api.Models.Product { Name="MacBook Pro 14\"", Slug="macbook-pro-14", Description="Mindenben Pro.", Category="Mac", Price=899990, Stock=8, Images="[\"/img/macbookpro14.png\"]", SpecsJson="{\"chip\":\"M3 Pro\"}" },
            new AppleAuth.Api.Models.Product { Name="iPad Pro", Slug="ipad-pro", Description="Lélegzetelállítóan Pro.", Category="iPad", Price=649990, Stock=12, Images="[\"/img/ipadpro.png\"]" },
            new AppleAuth.Api.Models.Product { Name="Watch Ultra", Slug="watch-ultra", Description="Extrém teljesítmény.", Category="Watch", Price=399990, Stock=20, Images="[\"/img/watchultra.png\"]" },
            new AppleAuth.Api.Models.Product { Name="AirPods Pro", Slug="airpods-pro", Description="Lenyűgöző hang. Kiemelkedő csend.", Category="AirPods", Price=129990, Stock=30, Images="[\"/img/airpodspro.png\"]" },
        });
    }

    if (!db.Coupons.Any())
    {
        db.Coupons.AddRange(new[] {
            new AppleAuth.Api.Models.Coupon { Code="WELCOME10", PercentOff=10, IsActive=true },
            new AppleAuth.Api.Models.Coupon { Code="VIP5000", AmountOff=5000, IsActive=true }
        });
    }

    if (!db.Users.Any(u => u.Email == "admin@local"))
    {
        string password = "admin123";
        using var rng = System.Security.Cryptography.RandomNumberGenerator.Create();
        var salt = new byte[16]; rng.GetBytes(salt);
        string saltB64 = Convert.ToBase64String(salt);
        string hash = Convert.ToBase64String(Microsoft.AspNetCore.Cryptography.KeyDerivation.KeyDerivation.Pbkdf2(
            password: password,
            salt: salt,
            prf: Microsoft.AspNetCore.Cryptography.KeyDerivation.KeyDerivationPrf.HMACSHA256,
            iterationCount: 100000,
            numBytesRequested: 32));
        db.Users.Add(new AppleAuth.Api.Models.User { Email = "admin@local", PasswordHash = $"{saltB64}:{hash}", IsAdmin = true });
    }

    db.SaveChanges();
}

app.MapControllers();
app.Run();