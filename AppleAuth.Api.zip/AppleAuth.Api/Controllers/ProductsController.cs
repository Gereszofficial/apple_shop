using AppleAuth.Api.Data;
using AppleAuth.Api.Dtos;
using AppleAuth.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AppleAuth.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProductsController : ControllerBase
    {
        private readonly AppDbContext _db;
        public ProductsController(AppDbContext db) { _db = db; }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAll() => Ok(await _db.Products.OrderByDescending(p => p.CreatedAt).ToListAsync());

        [HttpGet("{id:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetById(int id)
        {
            var e = await _db.Products.FindAsync(id);
            return e == null ? NotFound() : Ok(e);
        }

        [HttpGet("slug/{slug}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetBySlug(string slug)
        {
            var e = await _db.Products.SingleOrDefaultAsync(x => x.Slug == slug);
            return e == null ? NotFound() : Ok(e);
        }

        [HttpGet("search")]
        [AllowAnonymous]
        public async Task<IActionResult> Search([FromQuery] string? q, [FromQuery] string? category, [FromQuery] int? maxPrice)
        {
            var query = _db.Products.AsQueryable();
            if (!string.IsNullOrWhiteSpace(q)) query = query.Where(p => p.Name.Contains(q) || p.Description.Contains(q));
            if (!string.IsNullOrWhiteSpace(category)) query = query.Where(p => p.Category == category);
            if (maxPrice.HasValue) query = query.Where(p => p.Price <= maxPrice.Value);
            var list = await query.OrderByDescending(p => p.CreatedAt).Select(p => new ProductListItem {
                Id=p.Id, Name=p.Name, Slug=p.Slug, Category=p.Category, Price=p.Price, Stock=p.Stock, Thumbnail=p.Images
            }).ToListAsync();
            return Ok(list);
        }

        [HttpPost]
        [Authorize(Roles="Admin")]
        public async Task<IActionResult> Create([FromBody] ProductCreateRequest dto)
        {
            var e = new Product {
                Name = dto.Name,
                Slug = dto.Slug ?? dto.Name.Trim().ToLower().Replace(' ','-'),
                Description = dto.Description ?? string.Empty,
                Category = dto.Category ?? string.Empty,
                Images = dto.Images ?? "[]",
                Colors = dto.Colors ?? "[]",
                SpecsJson = dto.SpecsJson ?? "{}",
                Price = dto.Price,
                Stock = dto.Stock
            };
            _db.Products.Add(e);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = e.Id }, e);
        }

        [HttpPut("{id:int}")]
        [Authorize(Roles="Admin")]
        public async Task<IActionResult> Update(int id, [FromBody] ProductUpdateRequest dto)
        {
            var e = await _db.Products.FindAsync(id);
            if (e == null) return NotFound();
            e.Name = dto.Name ?? e.Name;
            e.Slug = dto.Slug ?? e.Slug;
            e.Description = dto.Description ?? e.Description;
            e.Category = dto.Category ?? e.Category;
            e.Images = dto.Images ?? e.Images;
            e.Colors = dto.Colors ?? e.Colors;
            e.SpecsJson = dto.SpecsJson ?? e.SpecsJson;
            e.Price = dto.Price != 0 ? dto.Price : e.Price;
            e.Stock = dto.Stock != 0 ? dto.Stock : e.Stock;
            await _db.SaveChangesAsync();
            return Ok(e);
        }

        [HttpDelete("{id:int}")]
        [Authorize(Roles="Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var e = await _db.Products.FindAsync(id);
            if (e == null) return NotFound();
            _db.Products.Remove(e);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}