using System.IO;
using AppleAuth.Api.Data;
using AppleAuth.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AppleAuth.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles="Admin")]
    public class AdminController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly IWebHostEnvironment _env;
        public AdminController(AppDbContext db, IWebHostEnvironment env) { _db = db; _env = env; }

        [HttpGet("coupons")]
        public async Task<IActionResult> Coupons() => Ok(await _db.Coupons.OrderByDescending(c => c.Id).ToListAsync());

        [HttpPost("coupons")]
        public async Task<IActionResult> CreateCoupon([FromBody] Coupon c) { _db.Coupons.Add(c); await _db.SaveChangesAsync(); return Ok(c); }

        [HttpPut("coupons/{id:int}")]
        public async Task<IActionResult> UpdateCoupon(int id, [FromBody] Coupon dto)
        {
            var c = await _db.Coupons.FindAsync(id); if (c == null) return NotFound();
            c.Code = dto.Code; c.PercentOff = dto.PercentOff; c.AmountOff = dto.AmountOff; c.IsActive = dto.IsActive; c.ExpiresAt = dto.ExpiresAt;
            await _db.SaveChangesAsync(); return Ok(c);
        }

        [HttpDelete("coupons/{id:int}")]
        public async Task<IActionResult> DeleteCoupon(int id) { var c = await _db.Coupons.FindAsync(id); if (c==null) return NotFound(); _db.Coupons.Remove(c); await _db.SaveChangesAsync(); return NoContent(); }

        [HttpGet("orders")]
        public async Task<IActionResult> Orders()
        {
            var list = await _db.Orders.OrderByDescending(o => o.CreatedAt).Select(o => new { o.Id, o.FullName, o.Email, o.Total, o.CreatedAt }).ToListAsync();
            return Ok(list);
        }

        [HttpPost("upload")]
        [RequestSizeLimit(20000000)]
        public async Task<IActionResult> Upload([FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0) return BadRequest(new { message = "Hiányzó fájl" });
            var root = _env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
            var uploads = Path.Combine(root, "uploads");
            Directory.CreateDirectory(uploads);
            var fname = $"{Guid.NewGuid():N}{Path.GetExtension(file.FileName)}";
            var path = Path.Combine(uploads, fname);
            using (var stream = System.IO.File.Create(path)) { await file.CopyToAsync(stream); }
            return Ok(new { url = $"/uploads/{fname}" });
        }
    }
}