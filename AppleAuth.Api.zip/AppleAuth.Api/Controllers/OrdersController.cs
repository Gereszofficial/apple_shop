using System.Security.Claims;
using AppleAuth.Api.Data;
using AppleAuth.Api.Dtos;
using AppleAuth.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AppleAuth.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class OrdersController : ControllerBase
    {
        private readonly AppDbContext _db;
        public OrdersController(AppDbContext db) { _db = db; }

        private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateOrderRequest dto)
        {
            if (dto.Items == null || dto.Items.Count == 0) return BadRequest(new { message = "Üres rendelés" });

            // Totals
            var subtotal = dto.Items.Sum(i => i.Price * i.Qty);
            int discount = 0;
            if (!string.IsNullOrWhiteSpace(dto.CouponCode))
            {
                var c = await _db.Coupons.SingleOrDefaultAsync(x => x.Code == dto.CouponCode && x.IsActive && (x.ExpiresAt == null || x.ExpiresAt > DateTime.UtcNow));
                if (c != null)
                {
                    var perc = c.PercentOff > 0 ? (subtotal * c.PercentOff) / 100 : 0;
                    discount = Math.Max(perc, c.AmountOff);
                }
            }
            var total = Math.Max(0, subtotal - discount);

            var order = new Order {
                UserId = CurrentUserId,
                FullName = dto.FullName,
                Email = dto.Email,
                Address = dto.Address,
                Subtotal = subtotal,
                Discount = discount,
                Total = total,
                CouponCode = dto.CouponCode
            };
            order.Items = dto.Items.Select(i => new OrderItem {
                ProductName = i.Name, ProductPrice = i.Price, Qty = i.Qty
            }).ToList();

            _db.Orders.Add(order);
            await _db.SaveChangesAsync();
            return Ok(new { orderId = order.Id, total = order.Total });
        }

        [HttpGet("my")]
        public async Task<IActionResult> MyOrders()
        {
            var uid = CurrentUserId;
            var list = await _db.Orders
                .Where(o => o.UserId == uid)
                .OrderByDescending(o => o.CreatedAt)
                .Select(o => new {
                    o.Id, o.Total, o.Discount, o.Subtotal, o.CouponCode, o.CreatedAt,
                    Items = o.Items.Select(i => new { i.ProductName, i.ProductPrice, i.Qty })
                })
                .ToListAsync();
            return Ok(list);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            var uid = CurrentUserId;
            var o = await _db.Orders.Include(x => x.Items).SingleOrDefaultAsync(x => x.Id == id && x.UserId == uid);
            return o == null ? NotFound() : Ok(o);
        }
    }
}