using System.IO;
using System.Security.Claims;
using AppleAuth.Api.Data;
using AppleAuth.Api.Dtos;
using AppleAuth.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AppleAuth.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProfileController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly IWebHostEnvironment _env;

        public ProfileController(AppDbContext db, IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }

        private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        [HttpGet("me")]
        public async Task<IActionResult> Me()
        {
            var uid = CurrentUserId;
            var p = await _db.Profiles.SingleOrDefaultAsync(x => x.UserId == uid);
            if (p == null)
            {
                p = new UserProfile { UserId = uid };
                _db.Profiles.Add(p);
                await _db.SaveChangesAsync();
            }
            return Ok(p);
        }

        [HttpPut]
        public async Task<IActionResult> Update([FromBody] ProfileUpdateRequest dto)
        {
            var uid = CurrentUserId;
            var p = await _db.Profiles.SingleOrDefaultAsync(x => x.UserId == uid);
            if (p == null)
            {
                p = new UserProfile { UserId = uid };
                _db.Profiles.Add(p);
            }

            if (dto.FullName != null) p.FullName = dto.FullName;
            if (dto.Phone != null) p.Phone = dto.Phone;
            if (dto.Address != null) p.Address = dto.Address;
            if (dto.AvatarUrl != null) p.AvatarUrl = dto.AvatarUrl;

            await _db.SaveChangesAsync();
            return Ok(p);
        }

        [HttpPost("upload-avatar")]
        [RequestSizeLimit(10_000_000)]
        public async Task<IActionResult> UploadAvatar([FromForm] IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest(new { message = "Hiányzó fájl" });

            var root = _env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
            var dir = Path.Combine(root, "avatars");
            Directory.CreateDirectory(dir);

            var fname = $"{Guid.NewGuid():N}{Path.GetExtension(file.FileName)}";
            var path = Path.Combine(dir, fname);
            using (var s = System.IO.File.Create(path))
            {
                await file.CopyToAsync(s);
            }

            var url = $"/avatars/{fname}";

            var uid = CurrentUserId;
            var p = await _db.Profiles.SingleOrDefaultAsync(x => x.UserId == uid);
            if (p == null)
            {
                p = new UserProfile { UserId = uid, AvatarUrl = url };
                _db.Profiles.Add(p);
            }
            else
            {
                p.AvatarUrl = url;
            }

            await _db.SaveChangesAsync();
            return Ok(new { url });
        }
    }
}