using AppleAuth.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AppleAuth.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CouponsController : ControllerBase
    {
        private readonly AppDbContext _db;
        public CouponsController(AppDbContext db) { _db = db; }

        [HttpGet("validate")]
        [AllowAnonymous]
        public async Task<IActionResult> Validate([FromQuery]string code)
        {
            var c = await _db.Coupons.SingleOrDefaultAsync(x => x.Code == code && x.IsActive && (x.ExpiresAt==null || x.ExpiresAt > DateTime.UtcNow));
            if (c == null) return NotFound(new { message="Érvénytelen kupon" });
            return Ok(new { c.Code, c.PercentOff, c.AmountOff });
        }
    }
}