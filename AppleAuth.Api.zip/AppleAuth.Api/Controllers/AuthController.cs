using System.Security.Cryptography;
using AppleAuth.Api.Data;
using AppleAuth.Api.Dtos;
using AppleAuth.Api.Models;
using AppleAuth.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AppleAuth.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly TokenService _tokens;
        public AuthController(AppDbContext db, TokenService tokens) { _db = db; _tokens = tokens; }

        static string Hash(string password, byte[]? salt = null)
        {
            salt ??= RandomNumberGenerator.GetBytes(16);
            var hash = KeyDerivation.Pbkdf2(password, salt, KeyDerivationPrf.HMACSHA256, 100_000, 32);
            return Convert.ToBase64String(salt.Concat(hash).ToArray());
        }
        static bool Verify(string password, string stored)
        {
            var bytes = Convert.FromBase64String(stored);
            var salt = bytes.Take(16).ToArray();
            var hash = bytes.Skip(16).ToArray();
            var test = KeyDerivation.Pbkdf2(password, salt, KeyDerivationPrf.HMACSHA256, 100_000, 32);
            return CryptographicOperations.FixedTimeEquals(hash, test);
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.Email) || string.IsNullOrWhiteSpace(req.Password))
                return BadRequest(new { message = "Email és jelszó kötelező" });

            if (await _db.Users.AnyAsync(u => u.Email == req.Email))
                return Conflict(new { message = "Ez az email már regisztrálva van" });

            var user = new User { Email = req.Email, PasswordHash = Hash(req.Password) };
            _db.Users.Add(user);
            await _db.SaveChangesAsync();

            return Created("/api/auth/login", new { message = "Regisztráció sikeres" });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest req)
        {
            var user = await _db.Users.SingleOrDefaultAsync(u => u.Email == req.Email);
            if (user == null || !Verify(req.Password, user.PasswordHash))
                return Unauthorized(new { message = "Hibás belépési adatok" });

            var access = _tokens.CreateAccessToken(user);
            var refresh = _tokens.CreateRefreshToken(user);
            return Ok(new { user = new { user.Id, user.Email }, accessToken = access, refreshToken = refresh });
        }

        [Authorize]
        [HttpGet("me")]
        public async Task<IActionResult> Me()
        {
            var sub = User.Claims.FirstOrDefault(c => c.Type == "sub")?.Value;
            if (sub == null) return Unauthorized();
            var id = int.Parse(sub);
            var user = await _db.Users.AsNoTracking()
                          .Where(u => u.Id == id)
                          .Select(u => new { u.Id, u.Email, u.CreatedAt, u.IsAdmin })
                          .SingleOrDefaultAsync();
            if (user == null) return NotFound();
            return Ok(user);
        }
    }
}
